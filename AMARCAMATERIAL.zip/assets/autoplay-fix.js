(() => {
  const HERO_SELECTOR = '.hero video';
  const INSPIRE_SCOPE = '.inspire-carousel';
  const INSPIRE_VIDEO_SELECTOR = 'video.inspire-video';

  const forceInlineMuted = (v) => {
    try {
      v.muted = true;
      v.defaultMuted = true;
      v.playsInline = true;
      v.setAttribute('muted', '');
      v.setAttribute('playsinline', '');
      v.setAttribute('webkit-playsinline', '');
    } catch (e) {}
  };

  const safePlay = async (v) => {
    if (!v) return;
    forceInlineMuted(v);
    try { await v.play(); } catch (e) {}
  };

  // 1) HERO: tenta tocar assim que der (e destrava no primeiro toque)
  const tryHero = () => {
    const heroVideo = document.querySelector(HERO_SELECTOR);
    if (heroVideo) safePlay(heroVideo);
  };

  // 2) INSPIRE: toca só o vídeo mais visível e pausa o resto
  const initInspire = () => {
    const scope = document.querySelector(INSPIRE_SCOPE);
    if (!scope) return;

    const videos = Array.from(scope.querySelectorAll(INSPIRE_VIDEO_SELECTOR));
    if (!videos.length) return;

    videos.forEach(forceInlineMuted);

    const pauseAllExcept = (keep) => {
      videos.forEach(v => {
        if (v !== keep) {
          try { v.pause(); } catch (e) {}
        }
      });
    };

    const playMostVisible = (entries) => {
      const best = entries
        .filter(e => e.isIntersecting)
        .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];

      if (best && best.intersectionRatio >= 0.6) {
        pauseAllExcept(best.target);
        safePlay(best.target);
      }
    };

    if ('IntersectionObserver' in window) {
      const io = new IntersectionObserver(playMostVisible, {
        threshold: [0, 0.25, 0.6, 0.85]
      });
      videos.forEach(v => io.observe(v));
    } else {
      // fallback simples
      safePlay(videos[0]);
    }
  };

  // roda ao carregar
  document.addEventListener('DOMContentLoaded', () => {
    tryHero();
    initInspire();
  });

  // destrava no primeiro gesto (iOS especialmente)
  const unlock = () => {
    tryHero();
    const firstInspire = document.querySelector(`${INSPIRE_SCOPE} ${INSPIRE_VIDEO_SELECTOR}`);
    if (firstInspire) safePlay(firstInspire);

    window.removeEventListener('touchstart', unlock, { passive: true });
    window.removeEventListener('click', unlock);
  };

  window.addEventListener('touchstart', unlock, { passive: true });
  window.addEventListener('click', unlock);
})();
